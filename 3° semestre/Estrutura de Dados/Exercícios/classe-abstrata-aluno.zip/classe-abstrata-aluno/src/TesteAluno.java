public class TesteAluno {
    public static void main(String[] args) {
       AlunoFundamental alunoFund = new AlunoFundamental(9821, "cleitu", 8.0, 9.0, 7.0 , 5.0);
       AlunoGraduacao alunoGrad = new AlunoGraduacao(7689, "gerso", 10.0, 5.0);
       AlunoPos alunoPos = new AlunoPos(3764, "admilto", 7.0, 8.7,10.0);

        System.out.println(alunoFund);
        System.out.println(alunoGrad);
        System.out.println(alunoPos);

        Escola escola = new Escola("USCS");
        escola.adicionaAluno(alunoFund);
        escola.adicionaAluno(alunoGrad);
        escola.adicionaAluno(alunoPos);

        escola.exibeTodos();

        escola.exibeAlunoGraduacao();

        escola.exibeAprovados();

        escola.buscarAluno(3764);
        escola.buscarAluno(8989);
    }
}