import java.util.ArrayList;
import java.util.List;

public class Escola {
    private String nome;
    private List<Aluno> alunos;

    public Escola(String nome) {
        this.nome = nome;
        alunos = new ArrayList();
    }

    public void adicionaAluno(Aluno a){
        if (a != null) {
            alunos.add(a);
        }
    }

    public void exibeTodos() {
        for (Aluno aluno:alunos) {
            System.out.println(aluno);
        }
    }

    public void exibeAlunoGraduacao() {
        for(Aluno aluno: alunos) {
            if (aluno instanceof AlunoGraduacao) {
                System.out.println(aluno);
            }
        }
    }

    public void exibeAprovados() {
        for(Aluno aluno: alunos) {
            if(aluno.calcularMedia() >= 6.0) {
                System.out.println(aluno);
            }
        }
    }

    public void buscarAluno(int ra) {
        Boolean encontrado = false;
        for (Aluno aluno:alunos) {
            if (aluno.getRa() == ra) {
                System.out.println(aluno);
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("Aluno não encontrado");
        }
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Aluno> getAlunos() {
        return alunos;
    }

    public void setAlunos(List<Aluno> alunos) {
        this.alunos = alunos;
    }
}
