package school.sptech.login02221024joao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Login02221024JoaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
