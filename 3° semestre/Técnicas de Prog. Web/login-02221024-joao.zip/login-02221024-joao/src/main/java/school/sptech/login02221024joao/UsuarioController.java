package school.sptech.login02221024joao;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {
    List<Usuario> usuarios;

    public UsuarioController() {
        usuarios = new ArrayList<>();
    }

    @PostMapping
    public Usuario cadastrar(@RequestBody Usuario novoUsuario) {
        usuarios.add(novoUsuario);
        return novoUsuario;
    }

    @PostMapping("/autenticacao/{usuario}/{senha}")
    public Usuario autenticar(
            @PathVariable String usuario,
            @PathVariable String senha
    ) {
        for (Usuario u: usuarios) {
            if(u.getUsuario().equals(usuario) && u.takeSenha().equals(senha)){
                u.setAutenticado(true);
                return u;
            }
        }
        return null;
    }

    @GetMapping
    public List<Usuario> retornar() {
        return usuarios;
    }

    @DeleteMapping("/autenticacao/{usuario}")
    public String logoff(@PathVariable String usuario) {
        for (Usuario u: usuarios) {
            if(u.getUsuario().equals(usuario)){
                if (u.isAutenticado() == true) {
                    u.setAutenticado(false);
                    return "Logoff do usuario " + usuario + " concluído";
                } else {
                    return "Usuário " + usuario + " não está autenticado";
                }
            }
        }
        return "Usuario " + usuario + " não encontrado";
    }
}
