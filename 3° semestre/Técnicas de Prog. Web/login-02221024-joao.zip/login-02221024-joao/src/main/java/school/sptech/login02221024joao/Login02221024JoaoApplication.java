package school.sptech.login02221024joao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Login02221024JoaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Login02221024JoaoApplication.class, args);
	}

}
