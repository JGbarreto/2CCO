package school.sptech.heroi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeroiApplicationTests {

	@Test
	void contextLoads() {
	}

}
