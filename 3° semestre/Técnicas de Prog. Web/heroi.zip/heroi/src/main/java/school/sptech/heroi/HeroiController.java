package school.sptech.heroi;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController

public class HeroiController {
    List<Heroi> herois = new ArrayList<>();
    @GetMapping("/herois")
    public List<Heroi> retornarCadastrados(){
    return herois;
    }

    @GetMapping("/herois/{indice}")
    public Heroi resgatarJson(
            @PathVariable int indice
    ) {
        if (indice < herois.size() && indice >= 0) {
            return herois.get(indice);
        }
        return null;
    }

    @GetMapping("/herois/cadastrar/{nome}/{habilidade}/{idade}/{forca}/{vivo}")
    public Heroi cadastrar(
            @PathVariable String nome,
            @PathVariable String habilidade,
            @PathVariable int idade,
            @PathVariable double forca,
            @PathVariable boolean vivo
    ) {
        Heroi novoHeroi = new Heroi(nome, habilidade, idade, forca, vivo);
        herois.add(novoHeroi);
        return novoHeroi;
    }

    @GetMapping("/herois/atualizar/{indice}/{nome}/{habilidade}/{idade}/{forca}/{vivo}")
    public Heroi atualizar(
            @PathVariable int indice,
            @PathVariable String nome,
            @PathVariable String habilidade,
            @PathVariable int idade,
            @PathVariable double forca,
            @PathVariable boolean vivo
    ) {
        if (indice < herois.size() && indice >= 0) {
            Heroi novoHeroi = new Heroi(nome, habilidade, idade, forca, vivo);
            herois.set(indice, novoHeroi);
            return novoHeroi;

        }
        return null;
    }

    @GetMapping("/herois/remover/{indice}")
    public String remover(
            @PathVariable int indice
    ) {
        if (indice < herois.size() && indice > 0) {
             herois.remove(indice);
             return "Heroi Removido";
        }

        return "Heroi não encontrado";
    }

    @GetMapping("/herois/consulta/{nome}")
    public List<String> consulta( @PathVariable String nome) {
        List<String> nomes = new ArrayList<>();
        for(Heroi heroi: herois) {
            if (heroi.getNome().contains(nome)){
                nomes.add(heroi.getNome());
            }
        }
        return nomes;
    }
}
