package school.sptech.heroi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HeroiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HeroiApplication.class, args);
	}

}
